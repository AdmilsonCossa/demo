define(['app' ], function(App) {
	var router = new App.router;
    Backbone.history.start();  
	return App;
});